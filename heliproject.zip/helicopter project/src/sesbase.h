/*
 * sesbase.h
 *
 *  Created on: 20Apr.,2018
 *      Author: lovin
 */

#ifndef SESBASE_H_
#define SESBASE_H_

class sesbase {
public:
	sesbase();
	virtual ~sesbase();
	float baseX, baseY;
	void drawBase();
};

#endif /* SESBASE_H_ */
